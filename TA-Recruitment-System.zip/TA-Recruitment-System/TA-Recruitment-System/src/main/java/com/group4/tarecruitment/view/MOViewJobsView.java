package com.group4.tarecruitment.view;

import com.group4.tarecruitment.model.Job;
import com.group4.tarecruitment.service.MOService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import com.group4.tarecruitment.util.ThemeManager;

import java.util.ArrayList;
import java.util.List;

public class MOViewJobsView {

    private final Stage stage;
    private final String moName;
    private final MOService moService = new MOService();
    private final int PAGE_SIZE = 8;
    private int currentPage = 1;

    private CheckBox javaCb;
    private CheckBox englishCb;
    private CheckBox teachingCb;
    private CheckBox pythonCb;
    private CheckBox officeCb;
    private ComboBox<String> statusCombo;
    private ComboBox<String> typeCombo;

    public MOViewJobsView(Stage stage, String moName) {
        this.stage = stage;
        this.moName = moName;
    }

    public Parent createContent() {
        Label title = new Label("My Posted Positions");
        title.setFont(new Font(22));
        title.setStyle("-fx-font-weight: bold; -fx-text-fill: #24304d;");

        Button refreshBtn = new Button("Refresh");
        Button postNewBtn = new Button("Post New Position");
        Button backBtn = new Button("Back");

        String btnStyle = "-fx-font-size: 14px; -fx-padding: 7 14; -fx-background-radius: 5; -fx-font-weight: bold;";
        refreshBtn.setStyle(btnStyle + "-fx-background-color: #3498db; -fx-text-fill: white;");
        postNewBtn.setStyle(btnStyle + "-fx-background-color: #27ae60; -fx-text-fill: white;");
        backBtn.setStyle(btnStyle + "-fx-background-color: #95a5a6; -fx-text-fill: white;");

        HBox topBar = new HBox(10, refreshBtn, postNewBtn, backBtn);
        topBar.setAlignment(Pos.CENTER_LEFT);

        javaCb = new CheckBox("Java");
        englishCb = new CheckBox("English");
        teachingCb = new CheckBox("Teaching");
        pythonCb = new CheckBox("Python");
        officeCb = new CheckBox("Office");

        statusCombo = new ComboBox<>();
        statusCombo.getItems().addAll("All", "Recruiting", "Closed");
        statusCombo.setValue("All");
        statusCombo.setPrefWidth(130);

        typeCombo = new ComboBox<>();
        typeCombo.getItems().addAll("All", "Module TA", "Invigilation TA");
        typeCombo.setValue("All");
        typeCombo.setPrefWidth(150);

        Button resetBtn = new Button("Reset");
        resetBtn.setStyle(btnStyle + "-fx-background-color: #e74c3c; -fx-text-fill: white;");

        HBox filterBar = new HBox(12);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(10, 0, 10, 0));
        filterBar.setStyle("-fx-background-color: rgba(255,255,255,0.7); -fx-background-radius: 10; -fx-padding: 12 15;");

        Label filterLabel = new Label("Skill Tags:");
        filterLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #4a5568;");

        Label statusLabel = new Label("Status:");
        statusLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #4a5568;");

        Label typeLabel = new Label("Type:");
        typeLabel.setStyle("-fx-font-weight: bold; -fx-text-fill: #4a5568;");

        filterBar.getChildren().addAll(
                filterLabel, javaCb, englishCb, teachingCb, pythonCb, officeCb,
                new Separator(),
                statusLabel, statusCombo,
                typeLabel, typeCombo,
                resetBtn
        );

        VBox jobListBox = new VBox(12);
        jobListBox.setPadding(new Insets(15));
        jobListBox.setStyle("-fx-background-color: #f8f9fa; -fx-background-radius: 12;");

        HBox pageBox = new HBox(10);
        Button prevBtn = new Button("Previous");
        Button nextBtn = new Button("Next");
        Label pageLabel = new Label("Page 1");
        prevBtn.setStyle(btnStyle + "-fx-background-color: #6c757d; -fx-text-fill: white;");
        nextBtn.setStyle(btnStyle + "-fx-background-color: #6c757d; -fx-text-fill: white;");
        pageBox.getChildren().addAll(prevBtn, pageLabel, nextBtn);
        pageBox.setAlignment(Pos.CENTER);

        loadJobs(jobListBox, pageLabel);

        refreshBtn.setOnAction(e -> {
            currentPage = 1;
            loadJobs(jobListBox, pageLabel);
        });

        postNewBtn.setOnAction(e -> {
            MOPostJobView postView = new MOPostJobView(stage, moName, moName + "@bupt.edu");
            stage.setScene(ThemeManager.createScene(postView.createContent(), 1000, 700));
        });

        backBtn.setOnAction(e -> {
            TeacherView teacherView = new TeacherView(stage, moName);
            stage.setScene(ThemeManager.createScene(teacherView.createContent(), 1000, 700));
        });

        prevBtn.setOnAction(e -> {
            if (currentPage > 1) {
                currentPage--;
                loadJobs(jobListBox, pageLabel);
            }
        });

        nextBtn.setOnAction(e -> {
            try {
                int totalPages = getTotalPages();
                if (currentPage < totalPages) {
                    currentPage++;
                    loadJobs(jobListBox, pageLabel);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        javaCb.setOnAction(e -> refreshFilteredJobs(jobListBox, pageLabel));
        englishCb.setOnAction(e -> refreshFilteredJobs(jobListBox, pageLabel));
        teachingCb.setOnAction(e -> refreshFilteredJobs(jobListBox, pageLabel));
        pythonCb.setOnAction(e -> refreshFilteredJobs(jobListBox, pageLabel));
        officeCb.setOnAction(e -> refreshFilteredJobs(jobListBox, pageLabel));
        statusCombo.setOnAction(e -> refreshFilteredJobs(jobListBox, pageLabel));
        typeCombo.setOnAction(e -> refreshFilteredJobs(jobListBox, pageLabel));

        resetBtn.setOnAction(e -> {
            javaCb.setSelected(false);
            englishCb.setSelected(false);
            teachingCb.setSelected(false);
            pythonCb.setSelected(false);
            officeCb.setSelected(false);
            statusCombo.setValue("All");
            typeCombo.setValue("All");
            currentPage = 1;
            loadJobs(jobListBox, pageLabel);
        });

        VBox root = new VBox(15, title, topBar, filterBar, jobListBox, new Separator(), pageBox);
        root.setPadding(new Insets(25));
        root.setStyle("-fx-background-color: linear-gradient(to bottom, #f7f8fd, #eef2fb);");
        return root;
    }

    private void refreshFilteredJobs(VBox jobListBox, Label pageLabel) {
        currentPage = 1;
        loadJobs(jobListBox, pageLabel);
    }

    private int getTotalPages() throws Exception {
        List<Job> filteredJobs = getFilteredJobs();
        if (filteredJobs.isEmpty()) {
            return 1;
        }
        return (int) Math.ceil((double) filteredJobs.size() / PAGE_SIZE);
    }

    private List<Job> getFilteredJobs() throws Exception {
        List<Job> jobs = moService.getMyPostedJobs(moName);
        List<Job> filteredJobs = new ArrayList<>();

        for (Job job : jobs) {
            if (matchesFilters(job)) {
                filteredJobs.add(job);
            }
        }

        return filteredJobs;
    }

    private boolean matchesFilters(Job job) {
        String skillRequirements = job.getSkillRequirements() == null
                ? ""
                : job.getSkillRequirements().toLowerCase();

        if (javaCb.isSelected() && !skillRequirements.contains("java")) {
            return false;
        }
        if (englishCb.isSelected() && !skillRequirements.contains("english")) {
            return false;
        }
        if (teachingCb.isSelected() && !skillRequirements.contains("teaching")) {
            return false;
        }
        if (pythonCb.isSelected() && !skillRequirements.contains("python")) {
            return false;
        }
        if (officeCb.isSelected() && !skillRequirements.contains("office")) {
            return false;
        }

        String selectedStatus = statusCombo.getValue();
        if (selectedStatus != null && !"All".equals(selectedStatus)) {
            if (job.getStatus() == null || !job.getStatus().equalsIgnoreCase(selectedStatus)) {
                return false;
            }
        }

        String selectedType = typeCombo.getValue();
        if (selectedType != null && !"All".equals(selectedType)) {
            if (job.getPositionType() == null || !job.getPositionType().equalsIgnoreCase(selectedType)) {
                return false;
            }
        }

        return true;
    }

    private void loadJobs(VBox jobListBox, Label pageLabel) {
        jobListBox.getChildren().clear();
        try {
            List<Job> filteredJobs = getFilteredJobs();
            int totalPages = filteredJobs.isEmpty() ? 1 : (int) Math.ceil((double) filteredJobs.size() / PAGE_SIZE);

            if (currentPage > totalPages) {
                currentPage = totalPages;
            }
            if (currentPage < 1) {
                currentPage = 1;
            }

            int start = (currentPage - 1) * PAGE_SIZE;
            int end = Math.min(start + PAGE_SIZE, filteredJobs.size());

            List<Job> pageJobs = filteredJobs.isEmpty() ? new ArrayList<>() : filteredJobs.subList(start, end);

            if (pageJobs.isEmpty()) {
                Label emptyLabel = new Label("No positions found");
                emptyLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #7f8c8d; -fx-padding: 30;");
                jobListBox.getChildren().add(emptyLabel);
                pageLabel.setText("Page 1 / 1");
                return;
            }

            for (Job job : pageJobs) {
                VBox jobCard = createJobCard(job);
                jobListBox.getChildren().add(jobCard);
            }

            pageLabel.setText(String.format("Page %d / %d", currentPage, totalPages));
        } catch (Exception e) {
            Label errorLabel = new Label("Load failed: " + e.getMessage());
            errorLabel.setStyle("-fx-text-fill: #e74c3c;");
            jobListBox.getChildren().add(errorLabel);
            e.printStackTrace();
        }
    }

    private VBox createJobCard(Job job) {
        VBox card = new VBox(10);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-background-color: white; -fx-background-radius: 10; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 8, 0, 0, 2);");

        HBox headerRow = new HBox(15);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        Label idLabel = new Label(job.getJobId());
        idLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold; -fx-text-fill: #3498db; " +
                "-fx-background-color: #e8f4fc; -fx-padding: 4 8; -fx-background-radius: 4;");

        Label courseLabel = new Label(job.getCourseName());
        courseLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label statusBadge = new Label(job.getStatus());
        String statusColor = "Recruiting".equals(job.getStatus()) ? "#27ae60" : "#95a5a6";
        statusBadge.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: white; " +
                "-fx-background-color: " + statusColor + "; -fx-padding: 3 10; -fx-background-radius: 10;");

        headerRow.getChildren().addAll(idLabel, courseLabel, statusBadge);

        HBox infoRow = new HBox(25);
        infoRow.setAlignment(Pos.CENTER_LEFT);

        Label typeIcon = new Label("📋");
        Label typeLabel = new Label(job.getPositionType());
        typeLabel.setStyle("-fx-text-fill: #4a5568; -fx-font-size: 13px;");

        Label workloadIcon = new Label("⏱");
        Label workloadLabel = new Label(job.getWeeklyWorkload() + " h/week");
        workloadLabel.setStyle("-fx-text-fill: #4a5568; -fx-font-size: 13px;");

        Label timeIcon = new Label("📅");
        Label timeLabel = new Label(job.getReleaseTime());
        timeLabel.setStyle("-fx-text-fill: #718096; -fx-font-size: 12px;");

        infoRow.getChildren().addAll(typeIcon, typeLabel, workloadIcon, workloadLabel, timeIcon, timeLabel);

        HBox skillRow = new HBox(8);
        skillRow.setAlignment(Pos.CENTER_LEFT);
        Label skillTitle = new Label("Skills:");
        skillTitle.setStyle("-fx-font-size: 12px; -fx-text-fill: #718096; -fx-font-weight: bold;");

        String skills = job.getSkillRequirements() != null ? job.getSkillRequirements() : "";
        String[] skillArray = skills.split("[,;，；]");

        for (String skill : skillArray) {
            String trimmed = skill.trim();
            if (!trimmed.isEmpty()) {
                Label tag = new Label(trimmed);
                tag.setStyle("-fx-font-size: 11px; -fx-text-fill: #6366f1; " +
                        "-fx-background-color: #eef2ff; -fx-padding: 2 8; -fx-background-radius: 8;");
                skillRow.getChildren().add(tag);
            }
        }

        if (skillRow.getChildren().size() == 1) {
            Label noSkill = new Label("N/A");
            noSkill.setStyle("-fx-font-size: 11px; -fx-text-fill: #9ca3af;");
            skillRow.getChildren().add(noSkill);
        }

        HBox buttonRow = new HBox(10);
        buttonRow.setAlignment(Pos.CENTER_RIGHT);

        Button detailBtn = new Button("View Details");
        Button editBtn = new Button("Edit");
        Button closeBtn = new Button("Close");

        String btnStyle = "-fx-font-size: 12px; -fx-padding: 5 12; -fx-background-radius: 5; -fx-font-weight: bold;";
        detailBtn.setStyle(btnStyle + "-fx-background-color: #3498db; -fx-text-fill: white;");
        editBtn.setStyle(btnStyle + "-fx-background-color: #f39c12; -fx-text-fill: white;");
        closeBtn.setStyle(btnStyle + "-fx-background-color: #e74c3c; -fx-text-fill: white;");

        if (!"Recruiting".equals(job.getStatus())) {
            editBtn.setDisable(true);
            closeBtn.setDisable(true);
            editBtn.setStyle(btnStyle + "-fx-background-color: #bdc3c7; -fx-text-fill: white;");
            closeBtn.setStyle(btnStyle + "-fx-background-color: #bdc3c7; -fx-text-fill: white;");
        }

        detailBtn.setOnAction(e -> {
            MOJobDetailView detailView = new MOJobDetailView(stage, moName, job);
            stage.getScene().setRoot(detailView.createContent());
            stage.setTitle("Position Details");
        });

        editBtn.setOnAction(e -> {
            MOEditJobView editView = new MOEditJobView(stage, moName, job);
            stage.setScene(ThemeManager.createScene(editView.createContent(), 1000, 700));
        });

        closeBtn.setOnAction(e -> {
            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Close");
            confirm.setHeaderText("Close Position");
            confirm.setContentText("Are you sure you want to close this position?\n" +
                    "Position ID: " + job.getJobId() + "\n" +
                    "Course: " + job.getCourseName());

            confirm.showAndWait().ifPresent(response -> {
                if (response == ButtonType.OK) {
                    try {
                        boolean success = moService.closeJob(job.getJobId(), moName);
                        if (success) {
                            Alert alert = new Alert(Alert.AlertType.INFORMATION);
                            alert.setTitle("Success");
                            alert.setContentText("Position closed successfully!");
                            alert.showAndWait();
                            VBox jobListBox = (VBox) ((VBox) card.getParent()).getChildren().get(3);
                            Label pageLabel = (Label) ((HBox) ((VBox) card.getParent().getParent()).getChildren().get(5)).getChildren().get(1);
                            loadJobs(jobListBox, pageLabel);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            });
        });

        buttonRow.getChildren().addAll(detailBtn, editBtn, closeBtn);

        card.getChildren().addAll(headerRow, infoRow, skillRow, buttonRow);

        return card;
    }
}
