package com.group4.tarecruitment.view;

import com.group4.tarecruitment.model.Job;
import com.group4.tarecruitment.service.MOService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import com.group4.tarecruitment.util.ThemeManager;

public class MOJobDetailView {
    private final Stage stage;
    private final String moName;
    private final Job job;
    private final MOService moService = new MOService();

    public MOJobDetailView(Stage stage, String moName, Job job) {
        this.stage = stage;
        this.moName = moName;
        this.job = job;
    }

    public Parent createContent() {
        Label headerIcon = new Label("🎓");
        headerIcon.setStyle("-fx-font-size: 40px;");

        Label title = new Label("Position Details");
        title.setFont(new Font(22));
        title.setStyle("-fx-font-weight: bold; -fx-text-fill: #24304d;");

        VBox header = new VBox(5, title);
        header.setAlignment(Pos.CENTER_LEFT);

        VBox mainCard = new VBox(20);
        mainCard.setPadding(new Insets(25));
        mainCard.setStyle("-fx-background-color: white; -fx-background-radius: 16; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 15, 0, 0, 4);");

        VBox basicInfo = createSectionCard("📋 Basic Information",
                createInfoRow("Position ID", job.getJobId()),
                createInfoRow("Course Name", job.getCourseName()),
                createInfoRow("Position Type", job.getPositionType()),
                createInfoRow("Weekly Workload", job.getWeeklyWorkload() + " hours/week"),
                createInfoRow("Status", job.getStatus(), isRecruiting() ? "#27ae60" : "#95a5a6"));

        VBox contactInfo = createSectionCard("👤 MO Information",
                createInfoRow("MO Name", job.getMoName()),
                createInfoRow("MO Email", job.getMoEmail() != null ? job.getMoEmail() : "N/A"));

        VBox timeInfo = createSectionCard("⏰ Timeline",
                createInfoRow("Release Time", job.getReleaseTime() != null ? job.getReleaseTime() : "N/A"),
                createInfoRow("Deadline", job.getDeadline() != null ? job.getDeadline() : "N/A"));

        VBox skillInfo = createSkillSection("💡 Skill Requirements", job.getSkillRequirements());
        VBox contentInfo = createContentSection("📝 Job Content", job.getJobContent());

        mainCard.getChildren().addAll(basicInfo, contactInfo, timeInfo, skillInfo, contentInfo);

        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(10, 0, 0, 0));

        Button backBtn = new Button("← Back to List");
        Button editBtn = new Button("✏ Edit Position");
        Button closeBtn = new Button("🚫 Close Position");
        Button viewAppsBtn = new Button("📂 View Applications");

        String btnStyle = "-fx-font-size: 14px; -fx-padding: 10 20; -fx-background-radius: 8; -fx-font-weight: bold;";
        backBtn.setStyle(btnStyle + "-fx-background-color: #6c757d; -fx-text-fill: white;");
        editBtn.setStyle(btnStyle + "-fx-background-color: #f39c12; -fx-text-fill: white;");
        closeBtn.setStyle(btnStyle + "-fx-background-color: #e74c3c; -fx-text-fill: white;");
        viewAppsBtn.setStyle(btnStyle + "-fx-background-color: #3498db; -fx-text-fill: white;");

        if (!isRecruiting()) {
            editBtn.setDisable(true);
            closeBtn.setDisable(true);
            editBtn.setStyle(btnStyle + "-fx-background-color: #bdc3c7; -fx-text-fill: white;");
            closeBtn.setStyle(btnStyle + "-fx-background-color: #bdc3c7; -fx-text-fill: white;");
        }

        backBtn.setOnAction(e -> {
            MOViewJobsView jobsView = new MOViewJobsView(stage, moName);
            stage.getScene().setRoot(jobsView.createContent());
            stage.setTitle("My Posted Positions");
        });

        editBtn.setOnAction(e -> {
            MOEditJobView editView = new MOEditJobView(stage, moName, job);
            stage.setScene(ThemeManager.createScene(editView.createContent(), 1000, 700));
        });

        closeBtn.setOnAction(e -> {
            javafx.scene.control.Alert confirm = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.CONFIRMATION);
            confirm.setTitle("Confirm Close");
            confirm.setHeaderText("Close Position");
            confirm.setContentText("Are you sure you want to close this position?\n" +
                    "Position ID: " + job.getJobId() + "\n" +
                    "Course: " + job.getCourseName());

            confirm.showAndWait().ifPresent(response -> {
                if (response == javafx.scene.control.ButtonType.OK) {
                    try {
                        boolean success = moService.closeJob(job.getJobId(), moName);
                        if (success) {
                            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
                            alert.setTitle("Success");
                            alert.setContentText("Position closed successfully!");
                            alert.showAndWait();
                            MOViewJobsView jobsView = new MOViewJobsView(stage, moName);
                            stage.getScene().setRoot(jobsView.createContent());
                            stage.setTitle("My Posted Positions");
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            });
        });

        viewAppsBtn.setOnAction(e -> {
            MOViewApplicationsView appsView = new MOViewApplicationsView(stage, moName, job);
            stage.setScene(ThemeManager.createScene(appsView.createContent(), 1100, 700));
        });

        buttonBox.getChildren().addAll(backBtn, editBtn, closeBtn, viewAppsBtn);

        VBox root = new VBox(20, header, mainCard, buttonBox);
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: linear-gradient(to bottom, #f7f8fd, #eef2fb);");
        root.setAlignment(Pos.TOP_CENTER);

        return root;
    }

    private boolean isRecruiting() {
        return "Recruiting".equals(job.getStatus());
    }

    private VBox createSectionCard(String title, HBox... rows) {
        VBox section = new VBox(12);
        section.setPadding(new Insets(15));
        section.setStyle("-fx-background-color: #f8f9fa; -fx-background-radius: 12;");

        Label sectionTitle = new Label(title);
        sectionTitle.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; " +
                "-fx-border-color: #3498db; -fx-border-width: 0 0 2 0; -fx-padding: 0 0 5 0;");

        section.getChildren().add(sectionTitle);
        for (HBox row : rows) {
            section.getChildren().add(row);
        }

        return section;
    }

    private HBox createInfoRow(String label, String value) {
        return createInfoRow(label, value, "#4a5568");
    }

    private HBox createInfoRow(String label, String value, String valueColor) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER_LEFT);

        Label labelNode = new Label(label + ":");
        labelNode.setStyle("-fx-font-size: 14px; -fx-font-weight: 600; -fx-text-fill: #4a5568; -fx-min-width: 120;");

        Label valueNode = new Label(value != null ? value : "N/A");
        valueNode.setStyle("-fx-font-size: 14px; -fx-text-fill: " + valueColor + "; -fx-wrap-text: true;");

        row.getChildren().addAll(labelNode, valueNode);
        return row;
    }

    private VBox createSkillSection(String title, String skills) {
        VBox section = new VBox(12);
        section.setPadding(new Insets(15));
        section.setStyle("-fx-background-color: #f8f9fa; -fx-background-radius: 12;");

        Label sectionTitle = new Label(title);
        sectionTitle.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; " +
                "-fx-border-color: #6366f1; -fx-border-width: 0 0 2 0; -fx-padding: 0 0 5 0;");

        section.getChildren().add(sectionTitle);

        if (skills == null || skills.trim().isEmpty()) {
            Label noSkill = new Label("No specific skills required");
            noSkill.setStyle("-fx-font-size: 13px; -fx-text-fill: #9ca3af; -fx-font-style: italic;");
            section.getChildren().add(noSkill);
        } else {
            HBox tagContainer = new HBox(8);
            tagContainer.setAlignment(Pos.CENTER_LEFT);

            String[] skillArray = skills.split("[,;，；]");
            for (String skill : skillArray) {
                String trimmed = skill.trim();
                if (!trimmed.isEmpty()) {
                    Label tag = new Label(trimmed);
                    tag.setStyle("-fx-font-size: 13px; -fx-text-fill: #6366f1; " +
                            "-fx-background-color: #eef2ff; -fx-padding: 5 12; -fx-background-radius: 15; " +
                            "-fx-font-weight: 500;");
                    tagContainer.getChildren().add(tag);
                }
            }

            section.getChildren().add(tagContainer);
        }

        return section;
    }

    private VBox createContentSection(String title, String content) {
        VBox section = new VBox(12);
        section.setPadding(new Insets(15));
        section.setStyle("-fx-background-color: #f8f9fa; -fx-background-radius: 12;");

        Label sectionTitle = new Label(title);
        sectionTitle.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; " +
                "-fx-border-color: #27ae60; -fx-border-width: 0 0 2 0; -fx-padding: 0 0 5 0;");

        section.getChildren().add(sectionTitle);

        Label contentLabel = new Label(content != null && !content.trim().isEmpty() ? content : "No job content provided");
        contentLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #4a5568; -fx-wrap-text: true; " +
                "-fx-line-spacing: 5;");
        contentLabel.setPrefWidth(700);

        section.getChildren().add(contentLabel);

        return section;
    }
}
