package com.group4.tarecruitment.view;

import com.group4.tarecruitment.model.Application;
import com.group4.tarecruitment.model.Job;
import com.group4.tarecruitment.service.ApplicantService;
import com.group4.tarecruitment.service.MOService;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.ScrollPane;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import com.group4.tarecruitment.util.ThemeManager;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

public class MOViewApplicationsView {

    private final Stage stage;
    private final String moName;
    private final MOService moService = new MOService();
    private final ApplicantService applicantService = new ApplicantService();

    private VBox appListBox;
    private ComboBox<Job> jobComboBox;
    private ComboBox<String> statusFilter;
    private Job selectedJob;
    private Label jobInfoLabel;
    private Label pageLabel;
    private final int PAGE_SIZE = 6;
    private int currentPage = 1;
    private List<Application> allApplications = new ArrayList<>();

    public MOViewApplicationsView(Stage stage, String moName) {
        this.stage = stage;
        this.moName = moName;
    }

    public MOViewApplicationsView(Stage stage, String moName, Job selectedJob) {
        this.stage = stage;
        this.moName = moName;
        this.selectedJob = selectedJob;
    }

    public Parent createContent() {
        Label title = new Label("Review TA Applications");
        title.setFont(new Font(22));
        title.setStyle("-fx-font-weight: bold; -fx-text-fill: #24304d;");

        VBox header = new VBox(5, title);
        header.setAlignment(Pos.CENTER_LEFT);

        VBox filterCard = new VBox(15);
        filterCard.setPadding(new Insets(18));
        filterCard.setStyle("-fx-background-color: white; -fx-background-radius: 12; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 8, 0, 0, 2);");

        Label filterTitle = new Label("🔍 Filter Applications");
        filterTitle.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; " +
                "-fx-border-color: #3498db; -fx-border-width: 0 0 2 0; -fx-padding: 0 0 5 0;");

        HBox filterRow = new HBox(20);
        filterRow.setAlignment(Pos.CENTER_LEFT);

        Label jobLabel = new Label("Select Position:");
        jobLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 600; -fx-text-fill: #4a5568;");

        jobComboBox = new ComboBox<>();
        jobComboBox.setPrefWidth(280);
        jobComboBox.setPromptText("Select a position");

        Label statusLabel = new Label("Status:");
        statusLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: 600; -fx-text-fill: #4a5568;");

        statusFilter = new ComboBox<>();
        statusFilter.getItems().addAll("All", "Pending", "Approved", "Rejected");
        statusFilter.setValue("All");
        statusFilter.setPrefWidth(130);

        Button loadBtn = new Button("Load");
        String btnStyle = "-fx-font-size: 13px; -fx-padding: 8 16; -fx-background-radius: 6; -fx-font-weight: bold;";
        loadBtn.setStyle(btnStyle + "-fx-background-color: #3498db; -fx-text-fill: white;");

        Button resetBtn = new Button("Reset");
        resetBtn.setStyle(btnStyle + "-fx-background-color: #95a5a6; -fx-text-fill: white;");

        filterRow.getChildren().addAll(jobLabel, jobComboBox, statusLabel, statusFilter, loadBtn, resetBtn);

        jobInfoLabel = new Label();
        jobInfoLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #718096;");

        filterCard.getChildren().addAll(filterTitle, filterRow, jobInfoLabel);

        VBox listCard = new VBox(15);
        listCard.setPadding(new Insets(18));
        listCard.setStyle("-fx-background-color: white; -fx-background-radius: 12; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 8, 0, 0, 2);");

        Label listTitle = new Label("📋 Application List");
        listTitle.setStyle("-fx-font-size: 15px; -fx-font-weight: bold; -fx-text-fill: #2c3e50; " +
                "-fx-border-color: #9b59b6; -fx-border-width: 0 0 2 0; -fx-padding: 0 0 5 0;");

        appListBox = new VBox(12);
        appListBox.setPadding(new Insets(10));
        appListBox.setStyle("-fx-background-color: #f8f9fa; -fx-background-radius: 8;");

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(appListBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setPrefHeight(400);
        scrollPane.setStyle("-fx-background-color: transparent; -fx-background: #f8f9fa; -fx-background-radius: 8;");
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        HBox pageBox = new HBox(15);
        pageBox.setAlignment(Pos.CENTER);
        Button prevBtn = new Button("← Previous");
        Button nextBtn = new Button("Next →");
        pageLabel = new Label("Page 1 / 1");
        prevBtn.setStyle(btnStyle + "-fx-background-color: #6c757d; -fx-text-fill: white;");
        nextBtn.setStyle(btnStyle + "-fx-background-color: #6c757d; -fx-text-fill: white;");
        pageBox.getChildren().addAll(prevBtn, pageLabel, nextBtn);

        listCard.getChildren().addAll(listTitle, scrollPane, pageBox);

        HBox buttonBox = new HBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.setPadding(new Insets(10, 0, 0, 0));

        Button backBtn = new Button("← Back");
        backBtn.setStyle(btnStyle + "-fx-background-color: #6c757d; -fx-text-fill: white;");

        buttonBox.getChildren().addAll(backBtn);

        Label statusMsgLabel = new Label();
        statusMsgLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-size: 13px; -fx-padding: 5 0 0 0;");

        loadJobs();

        loadBtn.setOnAction(e -> {
            Job selected = jobComboBox.getValue();
            if (selected != null) {
                jobInfoLabel.setText("📌 Current Position: " + selected.getCourseName() + " (" + selected.getJobId() + ")");
            }
            currentPage = 1;
            loadApplications();
        });

        resetBtn.setOnAction(e -> {
            jobComboBox.setValue(null);
            statusFilter.setValue("All");
            jobInfoLabel.setText("");
            allApplications.clear();
            appListBox.getChildren().clear();
            pageLabel.setText("Page 1 / 1");
        });

        statusFilter.setOnAction(e -> {
            if (jobComboBox.getValue() != null) {
                currentPage = 1;
                loadApplications();
            }
        });

        prevBtn.setOnAction(e -> {
            if (currentPage > 1) {
                currentPage--;
                displayApplications();
            }
        });

        nextBtn.setOnAction(e -> {
            int totalPages = getTotalPages();
            if (currentPage < totalPages) {
                currentPage++;
                displayApplications();
            }
        });

        backBtn.setOnAction(e -> {
            if (selectedJob != null) {
                MOJobDetailView detailView = new MOJobDetailView(stage, moName, selectedJob);
                stage.getScene().setRoot(detailView.createContent());
                stage.setTitle("Position Details");
            } else {
                TeacherView teacherView = new TeacherView(stage, moName);
                stage.setScene(ThemeManager.createScene(teacherView.createContent(), 1000, 700));
            }
        });

        VBox root = new VBox(20, header, filterCard, listCard, buttonBox, statusMsgLabel);
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: linear-gradient(to bottom, #f7f8fd, #eef2fb);");

        return root;
    }

    private void loadJobs() {
        try {
            List<Job> jobs = moService.getMyPostedJobs(moName);
            jobComboBox.getItems().clear();
            jobComboBox.getItems().addAll(jobs);
            
            if (selectedJob != null) {
                for (Job job : jobs) {
                    if (job.getJobId().equals(selectedJob.getJobId())) {
                        jobComboBox.setValue(job);
                        jobInfoLabel.setText("📌 Current Position: " + job.getCourseName() + " (" + job.getJobId() + ")");
                        loadApplications();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private int getTotalPages() {
        if (allApplications.isEmpty()) {
            return 1;
        }
        return (int) Math.ceil((double) allApplications.size() / PAGE_SIZE);
    }

    private void loadApplications() {
        Job job = jobComboBox.getValue();
        if (job == null) {
            return;
        }

        try {
            List<Application> apps = moService.getJobApplications(job.getJobId(), moName);

            String filter = statusFilter.getValue();
            if (!"All".equals(filter)) {
                apps = apps.stream()
                        .filter(a -> a.getStatus().equals(filter))
                        .toList();
            }

            allApplications = new ArrayList<>(apps);
            displayApplications();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void displayApplications() {
        appListBox.getChildren().clear();

        if (allApplications.isEmpty()) {
            Label emptyLabel = new Label("📭 No applications found");
            emptyLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #7f8c8d; -fx-padding: 30;");
            appListBox.getChildren().add(emptyLabel);
            pageLabel.setText("Page 1 / 1");
            return;
        }

        int totalPages = getTotalPages();
        if (currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;

        int start = (currentPage - 1) * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, allApplications.size());

        List<Application> pageApps = allApplications.subList(start, end);

        for (Application app : pageApps) {
            VBox card = createApplicationCard(app);
            appListBox.getChildren().add(card);
        }

        pageLabel.setText(String.format("Page %d / %d", currentPage, totalPages));
    }

    private VBox createApplicationCard(Application app) {
        VBox card = new VBox(12);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-background-color: white; -fx-background-radius: 10; " +
                "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 6, 0, 0, 2);");

        HBox headerRow = new HBox(15);
        headerRow.setAlignment(Pos.CENTER_LEFT);

        Label appIdLabel = new Label(app.getApplicationId());
        appIdLabel.setStyle("-fx-font-size: 13px; -fx-font-weight: bold; -fx-text-fill: #3498db; " +
                "-fx-background-color: #e8f4fc; -fx-padding: 4 10; -fx-background-radius: 6;");

        String taName = "Unknown";
        try {
            var applicant = applicantService.getApplicantById(app.getTaId());
            if (applicant != null) {
                taName = applicant.getName() != null ? applicant.getName() : "Unknown";
            }
        } catch (Exception e) {
        }

        Label taNameLabel = new Label(taName);
        taNameLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold; -fx-text-fill: #2c3e50;");

        Label statusBadge = new Label(app.getStatus());
        String statusColor;
        switch (app.getStatus()) {
            case "Pending":
                statusColor = "#f39c12";
                break;
            case "Approved":
                statusColor = "#27ae60";
                break;
            case "Rejected":
                statusColor = "#e74c3c";
                break;
            default:
                statusColor = "#95a5a6";
        }
        statusBadge.setStyle("-fx-font-size: 12px; -fx-font-weight: bold; -fx-text-fill: white; " +
                "-fx-background-color: " + statusColor + "; -fx-padding: 3 12; -fx-background-radius: 10;");

        headerRow.getChildren().addAll(appIdLabel, taNameLabel, statusBadge);

        HBox infoRow = new HBox(25);
        infoRow.setAlignment(Pos.CENTER_LEFT);

        Label taIdIcon = new Label("👤");
        Label taIdLabel = new Label(app.getTaId());
        taIdLabel.setStyle("-fx-text-fill: #4a5568; -fx-font-size: 13px;");

        Label timeIcon = new Label("📅");
        Label timeLabel = new Label(app.getApplicationTime() != null ? app.getApplicationTime() : "N/A");
        timeLabel.setStyle("-fx-text-fill: #718096; -fx-font-size: 12px;");

        infoRow.getChildren().addAll(taIdIcon, taIdLabel, timeIcon, timeLabel);

        HBox commentRow = new HBox(8);
        commentRow.setAlignment(Pos.CENTER_LEFT);
        Label commentIcon = new Label("💬");
        Label commentLabel = new Label("Comment: " + (app.getReviewComment() != null && !app.getReviewComment().isEmpty() 
                ? app.getReviewComment() : "No comment"));
        commentLabel.setStyle("-fx-font-size: 12px; -fx-text-fill: #718096;");
        commentLabel.setWrapText(true);
        commentRow.getChildren().addAll(commentIcon, commentLabel);

        HBox buttonRow = new HBox(10);
        buttonRow.setAlignment(Pos.CENTER_RIGHT);

        String btnStyle = "-fx-font-size: 12px; -fx-padding: 6 14; -fx-background-radius: 5; -fx-font-weight: bold;";

        Button viewProfileBtn = new Button("👤 Profile");
        viewProfileBtn.setStyle(btnStyle + "-fx-background-color: #9b59b6; -fx-text-fill: white;");

        Button approveBtn = new Button("✅ Approve");
        approveBtn.setStyle(btnStyle + "-fx-background-color: #27ae60; -fx-text-fill: white;");

        Button rejectBtn = new Button("❌ Reject");
        rejectBtn.setStyle(btnStyle + "-fx-background-color: #e74c3c; -fx-text-fill: white;");

        if (!"Pending".equals(app.getStatus())) {
            approveBtn.setDisable(true);
            rejectBtn.setDisable(true);
            approveBtn.setStyle(btnStyle + "-fx-background-color: #bdc3c7; -fx-text-fill: white;");
            rejectBtn.setStyle(btnStyle + "-fx-background-color: #bdc3c7; -fx-text-fill: white;");
        }

        viewProfileBtn.setOnAction(e -> showTAProfile(app.getTaId()));

        approveBtn.setOnAction(e -> reviewApplication(app, "Approved"));

        rejectBtn.setOnAction(e -> reviewApplication(app, "Rejected"));

        buttonRow.getChildren().addAll(viewProfileBtn, approveBtn, rejectBtn);

        card.getChildren().addAll(headerRow, infoRow, commentRow, buttonRow);

        return card;
    }

    private void showTAProfile(String taId) {
        try {
            var applicant = applicantService.getApplicantById(taId);
            if (applicant != null) {
                Dialog<Void> dialog = new Dialog<>();
                dialog.setTitle("TA Profile");
                dialog.setHeaderText("TA ID: " + taId);

                VBox content = new VBox();
                content.getStyleClass().add("profile-content");

                VBox profileSection = new VBox(16);
                profileSection.getStyleClass().add("profile-section");

                createStyledInfoRow(profileSection, "Name:", applicant.getName() != null ? applicant.getName() : "N/A");
                createStyledInfoRow(profileSection, "Email:", applicant.getEmail() != null ? applicant.getEmail() : "N/A");
                createStyledInfoRow(profileSection, "Phone:", applicant.getPhone() != null ? applicant.getPhone() : "N/A");

                HBox skillRow = new HBox(8);
                skillRow.setAlignment(Pos.CENTER_LEFT);
                Label skillTitle = new Label("Skills:");
                skillTitle.setStyle("-fx-font-size: 14px; -fx-font-weight: 600; -fx-text-fill: #4b5563; -fx-pref-width: 80;");
                skillRow.getChildren().add(skillTitle);
                
                String skills = applicant.getSkills();
                if (skills != null && !skills.trim().isEmpty()) {
                    String[] skillArray = skills.split("[,;，；]");
                    for (String skill : skillArray) {
                        String trimmed = skill.trim();
                        if (!trimmed.isEmpty()) {
                            Label tag = new Label(trimmed);
                            tag.setStyle("-fx-font-size: 12px; -fx-text-fill: #6366f1; " +
                                    "-fx-background-color: #eef2ff; -fx-padding: 3 10; -fx-background-radius: 10;");
                            skillRow.getChildren().add(tag);
                        }
                    }
                } else {
                    Label noSkill = new Label("N/A");
                    noSkill.setStyle("-fx-font-size: 12px; -fx-text-fill: #9ca3af;");
                    skillRow.getChildren().add(noSkill);
                }
                profileSection.getChildren().add(skillRow);

                VBox cvSection = new VBox(16);
                cvSection.getStyleClass().add("cv-section");
                
                HBox cvBox = new HBox(12);
                cvBox.getStyleClass().add("cv-box");
                
                Label cvPathLabel = new Label(applicant.getCvPath() != null ? applicant.getCvPath() : "N/A");
                cvPathLabel.getStyleClass().add("cv-path-label");
                
                Button downloadBtn = new Button("Download CV");
                downloadBtn.getStyleClass().add("download-btn");

                if (applicant.getCvPath() == null || applicant.getCvPath().isEmpty()) {
                    downloadBtn.setDisable(true);
                }

                downloadBtn.setOnAction(e -> downloadCV(applicant.getCvPath()));
                cvBox.getChildren().addAll(cvPathLabel, downloadBtn);
                cvSection.getChildren().add(cvBox);

                content.getChildren().addAll(profileSection, cvSection);

                ButtonType closeButtonType = new ButtonType("Close", ButtonBar.ButtonData.CANCEL_CLOSE);
                dialog.getDialogPane().getButtonTypes().add(closeButtonType);

                dialog.getDialogPane().getStyleClass().add("ta-profile-dialog");
                dialog.getDialogPane().setContent(content);
                
                String css = getClass().getResource("/styles/app-theme.css").toExternalForm();
                dialog.getDialogPane().getStylesheets().add(css);
                
                dialog.getDialogPane().setPrefWidth(550);
                dialog.getDialogPane().setPrefHeight(400);
                
                dialog.showAndWait();
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Not Found");
                alert.setContentText("TA profile not found!");
                alert.showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void createStyledInfoRow(VBox parent, String labelText, String value) {
        HBox row = new HBox(16);
        row.getStyleClass().add("profile-info-row");
        
        Label label = new Label(labelText);
        label.getStyleClass().add("profile-info-label");
        
        Label valueLabel = new Label(value);
        valueLabel.getStyleClass().add("profile-info-value");
        
        row.getChildren().addAll(label, valueLabel);
        parent.getChildren().add(row);
    }

    private void downloadCV(String cvPath) {
        if (cvPath == null || cvPath.isBlank()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("No CV");
            alert.setContentText("No CV file available for download!");
            alert.showAndWait();
            return;
        }

        try {
            String fileName = cvPath;
            if (cvPath.contains("\\")) {
                fileName = cvPath.substring(cvPath.lastIndexOf("\\") + 1);
            } else if (cvPath.contains("/")) {
                fileName = cvPath.substring(cvPath.lastIndexOf("/") + 1);
            }
            
            String[] possiblePaths = {
                "data/resumes/" + fileName,
                "../data/resumes/" + fileName,
                "TA-Recruitment-System/data/resumes/" + fileName,
                "../TA-Recruitment-System/data/resumes/" + fileName,
                "../../data/resumes/" + fileName,
                "../../TA-Recruitment-System/data/resumes/" + fileName,
                "resumes/" + fileName,
                "../resumes/" + fileName
            };

            File cvFile = null;

            for (String path : possiblePaths) {
                File tempFile = new File(path);
                if (tempFile.exists()) {
                    cvFile = tempFile;
                    break;
                }
            }

            if (cvFile == null || !cvFile.exists()) {
                try {
                    java.net.URL resourceUrl = getClass().getResource("/resumes/" + fileName);
                    if (resourceUrl != null) {
                        cvFile = new File(resourceUrl.toURI());
                    }
                } catch (Exception e) {
                }
            }

            if (cvFile == null || !cvFile.exists()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("File Not Found");
                alert.setContentText("CV file not found. Please ensure the file exists in the data/resumes directory.");
                alert.showAndWait();
                return;
            }

            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save CV File");
            fileChooser.setInitialFileName(cvFile.getName());
            fileChooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("All Files (*.*)", "*.*")
            );

            File saveFile = fileChooser.showSaveDialog(stage);

            if (saveFile != null) {
                Files.copy(
                        cvFile.toPath(),
                        saveFile.toPath(),
                        StandardCopyOption.REPLACE_EXISTING
                );

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Download Successful");
                alert.setContentText("CV file downloaded successfully!");
                alert.showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Download Failed");
            alert.setContentText("Failed to download CV file: " + e.getMessage());
            alert.showAndWait();
        }
    }

    private void reviewApplication(Application app, String result) {
        if (!"Pending".equals(app.getStatus())) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setContentText("Only 'Pending' applications can be reviewed!");
            alert.showAndWait();
            return;
        }

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Review Application");
        dialog.setHeaderText(result + " Application: " + app.getApplicationId());
        dialog.setContentText("Review Comment (optional, max 50 chars):");

        dialog.showAndWait().ifPresent(comment -> {
            if (comment.length() > 50) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("Comment must be 50 characters or less!");
                alert.showAndWait();
                return;
            }

            try {
                boolean success = moService.reviewApplication(app.getApplicationId(), moName, result, comment);
                if (success) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Success");
                    alert.setContentText("Application " + result.toLowerCase() + " successfully!");
                    alert.showAndWait();
                    loadApplications();
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setContentText("Failed to review application!");
                    alert.showAndWait();
                }
            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setContentText("Error: " + e.getMessage());
                alert.showAndWait();
                e.printStackTrace();
            }
        });
    }
}
